def select_clicks(raw_clicks, min_clicks=10):
    stripped = map(lambda text: text.strip(), raw_clicks)
    non_empty = filter(None, stripped)
    numbers = list(map(int, non_empty))
    qualified = list(filter(lambda count: count >= min_clicks, numbers))
    return (numbers, qualified)


student_id = input("請輸入完整學號：").strip().upper()
tail = student_id[-3:]
a = int(student_id[-3])
b = int(student_id[-2])
c = int(student_id[-1])
s = a + b + c

raw_clicks = [str(10 + a), "0", "", " " + str(5 + b) + " ",
              "   ", str(15 + c), str(5 + b)]
min_clicks = 5 + b

numbers, qualified = select_clicks(raw_clicks, min_clicks=min_clicks)

print(f"學號：{student_id}")
print(f"點擊門檻：{min_clicks}")
print(f"清理結果：{numbers}")
print(f"合格結果：{qualified}")
print(f"合格筆數：{len(qualified)}")
print(f"合格合計：{sum(qualified)}")

for rank, count in enumerate(sorted(qualified, reverse=True), start=1):
    print(f"第{rank}名：{count}次")

_, qualified_100 = select_clicks(raw_clicks, min_clicks=100)
print(f"門檻100合格結果：{qualified_100}")
print(f"門檻100合格筆數：{len(qualified_100)}")
print(f"門檻100合格合計：{sum(qualified_100)}")
if not qualified_100:
    print("無符合門檻的素材")
